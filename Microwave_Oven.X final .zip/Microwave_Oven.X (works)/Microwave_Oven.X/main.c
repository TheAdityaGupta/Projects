
#include "main.h"
#pragma config WDTE = OFF

unsigned char m = 0, s = 0, flag = 0;
int operation_flag=POWER_ON_SCREEN;
static void init_config(void) {
    init_clcd();
    init_matrix_keypad();
    read_matrix_keypad(STATE);
    FAN_DDR = 0;
    FAN = 0;
    init_timer2();
    GIE = 1;
    PEIE = 1;
    BUZZER = 0;
    BUZZER_DDR = 0;

}
// 1354 TIME reset_flag;


//void init_timer2(void) {
//    /* Selecting the scale as 1:16 */
//    T2CKPS0 = 1;
//    T2CKPS1 = 1;
//
//    /* Loading the Pre Load register with 250 */
//    PR2 = 250; //TMR2 -> 0 to 250
//
//    /* The timer interrupt is enabled */
//    TMR2IE = 1;
//
//    /* Switching on the Timer2 */
//    TMR2ON = 0;
//}

//void init_matrix_keypad(void) {
//    /* Setting the Columns as Inputs (RB2 - RB0)*/
//    //TRISB = TRISB | 0x07; xxxx xxxx | 0000 0111 =  xxxx x111
//    MATRIX_KEYPAD_COLUMN_PORT_DDR = MATRIX_KEYPAD_COLUMN_PORT_DDR | 0x07;
//
//
//    /* Setting the Rows as Output (RD3 - RD0)*/
//    MATRIX_KEYPAD_ROW_PORT_DDR = MATRIX_KEYPAD_ROW_PORT_DDR & 0xF0; // TRISD = TRISD & 0xF0 -> (TRISD0 to TRISD3)
//
//    /* Enabling PORTB Pullups */
//    nRBPU = 0;
//
//    /* Making all the Rows HIGH to start with */
//    ROW1 = HI;
//    ROW2 = HI;
//    ROW3 = HI;
//    ROW4 = HI;
//}

//static unsigned char scan_keypad(void) {
//    int i;
//
//    ROW1 = LOW;
//    ROW2 = HI;
//    ROW3 = HI;
//    ROW4 = HI;
//
//    for (i = 100; i--;);
//
//    if (COL1 == LOW) {
//        return 1;
//    } else if (COL2 == LOW) {
//        return 2;
//    } else if (COL3 == LOW) {
//        return 3;
//    }
//
//    ROW1 = HI;
//    ROW2 = LOW;
//    ROW3 = HI;
//    ROW4 = HI;
//
//    for (i = 100; i > 0; i--) {
//        ;
//    }
//
//    if (COL1 == LOW) {
//        return 4;
//    } else if (COL2 == LOW) {
//        return 5;
//    } else if (COL3 == LOW) {
//        return 6;
//    }
//
//    ROW1 = HI;
//    ROW2 = HI;
//    ROW3 = LOW;
//    ROW4 = HI;
//
//    for (i = 100; i > 0; i--);
//
//    if (COL1 == LOW) {
//        return 7;
//    } else if (COL2 == LOW) {
//        return 8;
//    } else if (COL3 == LOW) {
//        return 9;
//    }
//
//    ROW1 = HI;
//    ROW2 = HI;
//    ROW3 = HI;
//    ROW4 = LOW;
//
//    for (i = 100; i > 0; i--);
//
//    if (COL1 == LOW) {
//        return '*';
//    } else if (COL2 == LOW) {
//        return 0;
//    } else if (COL3 == LOW) {
//        return '#';
//    }
//
//    return ALL_RELEASED;
//}
//static unsigned char scan_keypad(void);
//unsigned char read_matrix_keypad(unsigned char mode) // LEVEL STATE 
//{
//    static unsigned char once = 1;
//    unsigned char key;
//
//    key = scan_keypad(); // 1 2 3 4  5 6 7 8 9 0 '*' '#' 
//
//    if (mode == LEVEL) {
//        return key; //// 1 2 3 4  5 6 7 8 9 0 '*' '#' ALL_RELEASED
//    } else // state change 
//    {
//        if ((key != ALL_RELEASED) && once) {
//            once = 0;
//            return key; // 1 2 3 4  5 6 7 8 9 0 '*' '#' ALL_RELEASED
//        } else if (key == ALL_RELEASED) {
//            once = 1;
//        }
//    }
//
//    return ALL_RELEASED;
//}
//
//void clcd_write(unsigned char byte, unsigned char mode) // byte -> 'A', 1
//{
//    CLCD_RS = (__bit) mode;
//
//    CLCD_DATA_PORT = byte & 0xF0; // 0x41 & 0xF0 : 0x40 : 0100 0000 (RD7 to RD4)
//    CLCD_EN = HI;
//    __delay_us(100);
//    CLCD_EN = LOW;
//
//    CLCD_DATA_PORT = (unsigned char) ((byte & 0x0F) << 4); // 0x41 & 0x0F : 0000 0001 << 4 = PORTD 
//    CLCD_EN = HI;
//    __delay_us(100);
//    CLCD_EN = LOW;
//
//    __delay_us(4100);
//}

//static void init_display_controller(void) {
//
//
//    clcd_write(FOUR_BIT_MODE, INST_MODE);
//    __delay_us(100);
//    clcd_write(TWO_LINES_5x8_4_BIT_MODE, INST_MODE);
//    __delay_us(100);
//    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
//    __delay_us(500);
//    clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
//    __delay_us(100);
//}

//void init_clcd(void)
//{
//    /* Setting the CLCD Data Port as Output */
//    CLCD_DATA_PORT_DDR = 0x00;
//    
//    /* Setting the RS and EN lines as Output */
//    CLCD_RS_DDR = 0;
//    CLCD_EN_DDR = 0;
//    
//    init_display_controller();
//}

//void clcd_putch(const char data, unsigned char addr)
//{
//    clcd_write(addr, INST_MODE);
//    clcd_write(data, DATA_MODE);
//}

//void clcd_print(const char *str, unsigned char addr)
//{
//    clcd_write(addr, INST_MODE);
//    
//    while (*str != '\0')
//    {
//        clcd_write(*str, DATA_MODE); 
//        str++;
//    }
//}
void menu_bar() {
    clcd_print("1. Micro", LINE1(0));
    clcd_print("2. Grill", LINE2(0));
    clcd_print("3. Convection", LINE3(0));
    clcd_print("4. Start", LINE4(0));
}
void main(void) {
    init_config();
//    operation_flag = POWER_ON;
    int reset_flag;
    unsigned char key;
    set_time(key, reset_flag);// TIME


    while (1) {
        key = read_matrix_keypad(STATE);
        if (operation_flag == MENU) {
            //                  clcd_print("hi",LINE4(4));
            if (key == 1) {
                operation_flag = MICRO;
                reset_flag = MODE_RESET;
                clear_screen();
                clcd_print("  POWER = 900W    ", LINE2(0));
                __delay_ms(3000);
                clear_screen();
//                set_time(key, reset_flag);
//                init_matrix_keypad();
//                read_matrix_keypad(STATE);

            } else if (key == 2) {
                operation_flag = GRILL;
                reset_flag = MODE_RESET;
                clear_screen();

            } else if (key == 3) {
                operation_flag = CONVECTION;
                reset_flag = MODE_RESET;
                clear_screen();
            } else if (key == 4) {
                s = 30;
                m = 0;
//                TMR2ON = 1;
                FAN = 1;
                clear_screen();
                                TMR2ON = 1;

                operation_flag = TIME_DISPLAY;
            }
        } else if (operation_flag == TIME_DISPLAY) {
            if (key == 4) {
                
                FAN=1;
                clear_screen();
                TMR2ON=1;
                
            } else if (key == 5) {
                operation_flag = PAUSE;
                FAN = 0;
                clear_screen();
                TMR2ON = 0;
                operation_flag = TIME_DISPLAY;
            } else if (key == 6) {
                operation_flag = STOP;
                clear_screen();
            } else if (operation_flag == PAUSE) {
                FAN = 1;
                TMR2ON = 1;
                operation_flag = TIME_DISPLAY;

            }
        }

        switch (operation_flag) {
            case POWER_ON:
                power_on_screen();
                operation_flag = MENU;
                clear_screen();
                break;
            case MENU:
                menu_bar();
                break;

            case MICRO:
                set_time(key, reset_flag);
                break;

            case GRILL:
                set_time(key, reset_flag);
                break;

            case CONVECTION:
                if (flag == 0) {
                    set_temp(key, reset_flag);
                    if (flag == 1) {
                        clear_screen();
//                        set_time(key, reset_flag);
                        clcd_print("if stat", LINE1(0));
                        reset_flag = MODE_RESET;
                        clear_screen();
                    }
                }else {
//                  
                        clcd_print("SET TIME (MM:SS)", LINE1(0));
    clcd_print("TIME- ", LINE2(0));// sec -. 0 to59
    
    clcd_print("*:CLEAR #:ENTER", LINE4(0));
    //clcd_print("else stat", LINE1(0));
                    set_time(key, reset_flag);
                }
                break;
            case TIME_DISPLAY:
                time_display_screen();
                break;
            case PAUSE:
                FAN = 0;
                TMR2ON = 0;
                
            case STOP:
                FAN = 0;
                TMR2ON = 0;
                operation_flag = MENU;
                break;
        }
    
    reset_flag = RESET_NOTHING;
    }
}

void time_display_screen(void){
    //Line1 display
    clcd_print(" TIME =  ", LINE1(0));
    //print min and sec
    clcd_putch( m/10 + '0', LINE1(9));
    clcd_putch( m%10 + '0', LINE1(10));
    clcd_putch(':', LINE1(11));

    //SEC0
    clcd_putch( s/10 + '0', LINE1(12));
    clcd_putch( s%10 + '0', LINE1(13));
    // print option
    clcd_print(" 4.Start/Resume", LINE2(0));
    clcd_print(" 5.Pause ", LINE3(0));
    clcd_print(" 6.Stop ", LINE4(0));
    if (s == 0 && m == 0) {
        clear_screen();
                FAN = 0;
        clcd_print("TIME UP", LINE2(0));
        BUZZER = 1;
        __delay_ms(3000);
        clear_screen();
        BUZZER = 0;
        TMR2ON = 0;
        operation_flag = MENU;
}
}

void clear_screen(void) {
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
    __delay_us(1000);
}

void power_on_screen(void) {
    unsigned char i;
    for (i = 0; i <= 16; i++) {
        clcd_putch(BAR, LINE1(i));
        __delay_us(1000);

    }
    clcd_print("  POWERING ON  ", LINE2(0));
    clcd_print(" Microwave Oven ", LINE3(0));
    for (i = 0; i <= 16; i++) {
        clcd_putch(BAR, LINE4(i));
        __delay_us(3000);
    }
}


void set_time(unsigned char key, int reset_flag)
{
    static unsigned char key_count, blink_pos, blink;
    static int wait;
    if( reset_flag == MODE_RESET)
    {
        key_count = 0;
        s = 0;
        m = 0;
        blink_pos = 0;//sec
        wait = 0;
        blink = 0;
        key = ALL_RELEASED;
    clcd_print("SET TIME (MM:SS)", LINE1(0));
    clcd_print("TIME- ", LINE2(0));// sec -. 0 to59
    
    clcd_print("*:CLEAR #:ENTER", LINE4(0));
    }
    
    if((key != '*') && (key != '#') && (key != ALL_RELEASED))
    {
        // key = 1
        key_count++; //1
        if(key_count <=2) //reading number of sec
        {
            s = s*10 + key;//sec=1 5
            blink_pos = 0;
        }
        else if((key_count ==3) )
                //&& (key_count <= 4))
            
        {
            m +=  key;
            blink_pos = 1;
        }
        else if((key_count ==4))
        {
             m = m*10 +  key;
            blink_pos = 1;
        }
         if (s >= 60) {
        m += s / 60;
        s %= 60;
    }
        
    }
    else if(key == '*') //sec or min
    {
        if( blink_pos == 0 || blink_pos == 1 )
        {
            s = 0;
            m=0;
            key_count = 0;
            blink_pos=0;
        }
//        else if(blink_pos == 1)
//        {
//            m = 0;
//            key_count = 2;
//        }
        
    }
    else if(key == '#')// enter mode
    {
        clear_screen();
        operation_flag = TIME_DISPLAY;
        FAN = ON;//Turn ON the fan
        /*Switching ON the Timer2*/
        TMR2ON = ON;
    }
    
    if(wait++ == 15)
    {
        wait = 0;
        blink = !blink;
        //Printing sec and min on the set time screen
        //MIN
        clcd_putch( m/10 + '0', LINE2(6));
        clcd_putch( m%10 + '0', LINE2(7));
        clcd_putch(':', LINE2(8));

        //SEC
        clcd_putch( s/10 + '0', LINE2(9));
        clcd_putch( s%10 + '0', LINE2(10));
    
    }
    
    if(blink)
    {
        switch(blink_pos)
        {
            case 0:
                 clcd_print("  ", LINE2(9));
                break;
            case 1:
                 clcd_print("  ", LINE2(6));
                break;
                    
                
        }
        
        
    }
  
}

//void set_time(unsigned char key, int reset_flag) {
//    static unsigned char key_count, blink, blinkp;
//    static int wait;
//
//    if (reset_flag == MODE_RESET) {
//        key_count = 0;
//        blink = 0;
//        s = 0;
//        m = 0;
//        wait = 0;
//        blinkp = 0;
////        key = ALL_RELEASED;
//
//        clcd_print("SET TIME(MM:SEC)", LINE1(0));
//        clcd_print("TIME- ", LINE2(0));
//
//        clcd_print("*:CLEAR  #:ENTER", LINE4(0));
//    }
//        //me
//             
//
//          
//        // !me
//        //     init_matrix_keypad();
//        //     read_matrix_keypad(STATE);
////    }
//    if ((key != '*')&&(key != '#')&&(key != ALL_RELEASED)) {
//
//        key_count++;
//        if (key_count <= 2) {
//            s = s * 10 + key;
//            blink = 0;
//            //             
//        } else if ((key_count > 2)&&(key_count <= 4)) {
//            m = m * 10 + key;
//            blink = 1;
//        }
//
//    } else if (key == '*') {
//        if (blink == 0) {
//            s = 0;
//            key_count = 0;
//        } else if (blink == 1) {
//            m = 0;
//            key_count = 1;
//        } 
//        
//    }
//    else if (key == '#') {
//            clear_screen();
//            operation_flag = TIME_DISPLAY;
//            FAN = 1;
//            TMR2ON = 1;
//        }
//     
//    if (wait++ == 15) {
//        wait = 0;
//        blinkp = !blinkp;
//        clcd_putch(m / 10 + '0', LINE2(6));
//        clcd_putch(m % 10 + '0', LINE2(7));
////
//        clcd_putch(':', LINE2(8));
//        clcd_putch(s / 10 + '0', LINE2(9));
//        clcd_putch(s % 10 + '0', LINE2(10));
//
//    }
//    if (blink) {
//
//        switch (blinkp) {
//            case 0:
//                clcd_print("  ", LINE2(9));
//                break;
//            case 1:
//                clcd_print("  ", LINE2(6));
//                break;
//        }
//    }
//    s=s*10+key;
//             m=m*10+key;
//        clcd_putch(m / 10 + '0', LINE2(6));
//        clcd_putch(m % 10 + '0', LINE2(7));
//
//        clcd_putch(':', LINE2(8));
//        clcd_putch(s / 10 + '0', LINE2(9));
//        clcd_putch(s % 10 + '0', LINE2(10));
//          s=s*10+key;
//                       m=m*10+key;
//}
//
//void time_display_screen(void) {
//    //     clear_screen();
//    clcd_print("TIME=  ", LINE1(0));
//    clcd_putch(m / 10 + '0', LINE1(9));
//    clcd_putch(m % 10 + '0', LINE1(10));
//
//    clcd_putch(':', LINE1(11));
//    clcd_putch(s / 10 + '0', LINE1(12));
//    clcd_putch(s % 10 + '0', LINE1(13));
//
//    clcd_print("4.START/RESUME", LINE2(0));
//    clcd_print("5.PAUSE", LINE3(0));
//    clcd_print("6.STOP", LINE4(0));
//    if (s == 0 && m == 0) {
//        clear_screen();
//        clcd_print("TIME UP", LINE2(0));
//        BUZZER = 1;
//        __delay_ms(3000);
//        clear_screen();
//        BUZZER = 0;
//        FAN = 0;
//        TMR2ON = 0;
//        operation_flag = MENU;
//    }
//
//}

void set_temp(unsigned char key, int reset_flag) {
    static unsigned char key_count, blinkp, temp;
    static int wait;
    if (reset_flag == MODE_RESET) {
        key_count = 0;
        wait = 0;
        blinkp = 0;
        temp = 0;
        flag = 0;
        key = ALL_RELEASED;
        clcd_print("SET TEMP (C) ", LINE1(0));
        clcd_print("MIN=70 MAX = 255", LINE2(0));
        clcd_print("TEMP = ", LINE3(0));
        clcd_print("*:Clear  #:Enter", LINE4(0));
    }
    if (wait++ == 15) {
        wait = 0;
        blinkp = !blinkp;
        clcd_putch((temp / 100) + '0', LINE3(8));
        clcd_putch((temp / 10) % 10 + '0', LINE3(9));
        clcd_putch((temp % 10) + '0', LINE3(10));
    }
    if (blinkp) {
        clcd_print("   ", LINE3(8));
    }
    if ((key != '*')&&(key != '#')&&(key != ALL_RELEASED)) {
        key_count++;
        if (key_count <= 3) {
            
            temp = temp * 10 + key;

        }
    } else if (key == '*') {
        temp = 0;
        key_count = 0;
    } else if (key == '#' && temp >=70) {
        clear_screen();
        clcd_print("  Pre heating  ", LINE1(0));
        clcd_print("  Time remaining", LINE2(0));
        TMR2ON = 1;
        s = 3;
        while (s != 0) 
        {
            clcd_putch((s / 100) + '0', LINE3(11));
            clcd_putch((s / 10) % 10 + '0', LINE3(12));
            clcd_putch((s % 10) + '0', LINE3(13));
        
//            
//            clcd_print("0: STOP", LINE4(9));
//            if(key == '*'){
//                TMR2ON = 0;
//                FAN=0;
//                flag=
//                operation_flag = STOP;
//                clear_screen();
                                      
            
        }
    
    if (s == 0) {

        TMR2ON = 0;
//        BUZZER=1;
//        __delay_ms(10000);//3sec
        flag = 1;
    }
    }
    
}



//void time_display_screen(void)
//{
//    //Line1 display
//    clcd_print(" TIME =  ", LINE1(0));
//    //print min and sec
//    clcd_putch( m/10 + '0', LINE1(9));
//    clcd_putch( m%10 + '0', LINE1(10));
//    clcd_putch(':', LINE1(11));
//
//    //SEC0
//    clcd_putch( s/10 + '0', LINE1(12));
//    clcd_putch( s%10 + '0', LINE1(13));
//    // print option
//    clcd_print(" 4.Start/Resume", LINE2(0));
//    clcd_print(" 5.Pause ", LINE3(0));
//    clcd_print(" 6.Stop ", LINE4(0));
//}

//just 1340
//void set_time(unsigned char key, int reset_flag)
//{
//    static unsigned char key_count, blink_pos, blink;
//    static int wait;
//    if( reset_flag == MODE_RESET)
//    {
//        key_count = 0;
//        s = 0;
//        m = 0;
//        blink_pos = 0;//sec
//        wait = 0;
//        blink = 0;
//        key = ALL_RELEASED;
//    clcd_print("SET TIME (MM:SS)", LINE1(0));
//    clcd_print("TIME- ", LINE2(0));// sec -. 0 to59
//    
//    clcd_print("*:CLEAR #:ENTER", LINE4(0));
//    }
//    
//    if((key != '*') && (key != '#') && (key != ALL_RELEASED))
//    {
//        // key = 1
//        key_count++; //1
//        if(key_count <=2) //reading number of sec
//        {
//            s = s*10 + key;//sec=1 5
//            blink_pos = 0;
//        }
//        else if((key_count > 2) && (key_count <= 4))
//            
//        {
//            m =m*10 + key;
//            blink_pos = 1;
//        }
//    }
//    else if(key == '*') //sec or min
//    {
//        if( blink_pos == 0 )
//        {
//            s = 0;
//            key_count = 0;
//        }
//        else if(blink_pos == 1)
//        {
//            m = 0;
//            key_count = 2;
//        }
//        
//    }
//    else if(key == '#')// enter mode
//    {
//        clear_screen();
//        operation_flag = TIME_DISPLAY;
//        FAN = 1;//Turn ON the fan
//        /*Switching ON the Timer2*/
//        TMR2ON = 1;
//    }
//    
//    if(wait++ == 15)
//    {
//        wait = 0;
//        blink = !blink;
//        //Printing sec and min on the set time screen
//        //MIN
//        clcd_putch( m/10 + '0', LINE2(6));
//        clcd_putch( m%10 + '0', LINE2(7));
//        clcd_putch(':', LINE2(8));
//
//        //SEC
//        clcd_putch( s/10 + '0', LINE2(9));
//        clcd_putch( s%10 + '0', LINE2(10));
//    
//    }
//    
//    if(blink)
//    {
//        switch(blink_pos)
//        {
//            case 0:
//                 clcd_print("  ", LINE2(9));
//                break;
//            case 1:
//                 clcd_print("  ", LINE2(6));
//                break;
//                    
//                
//        }
//        
//        
//    }
//  
//}


