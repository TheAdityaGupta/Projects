//#include <xc.h>
//#include "main.h"
//
//extern unsigned char sec, min; // sec =1 5
//void __interrupt() isr(void)
//{
//    static unsigned int count = 0;
//    
//    if (TMR2IF == 1)
//    {    
//        if (++count == 1250) // 1sec
//        {
//            count = 0;
//            if(sec > 0)// sec = 0
//            {
//                sec--;
//            }
//            else if((sec == 0) && (min > 0))
//            {
//                min--;
//                sec = 59;
//            }
//            
//        }
//        
//        TMR2IF = 0;
//    }
//}

#include <xc.h>
#include "main.h"

extern unsigned char  s,  m; //  s =1 5
void __interrupt() isr(void)
{
    static unsigned int count = 0;
    
    if (TMR2IF == 1)
    {    
        if (++count == 1250) // 1 s
        {
            count = 0;
            if( s > 0)//  s = 0
            {
                 s--;
            }
            else if(( s == 0) && ( m > 0))
            {
                 m--;
                 s = 59;
            }
            
        }
        
        TMR2IF = 0;
    }
}